function takequiz() {
	showSections([ "takequiz" ]);
    document.bgColor = '#63e064';
	$("#displaycoinstext").html(myCoins + " Coins");
	$("#quizpageshowcoinstext").html(myCoins + " Coins");
}

function showSections(sections) {
	hideAll();
	for (section in sections) {
		$("#" + sections[section]).show();
	}
}

function hideAll() {
	$("#takequiz").hide();
	$("#loginpage").hide();
	$("#invitefriends").hide();
	$("#getmorecoins").hide();
	$("#quizpage").hide();
	$("#aboutyou").hide();
	$("#quizpageshowcoins").hide();
	$("#quizpageshowcoinstext").hide();
	$("#myhome").hide();
}
