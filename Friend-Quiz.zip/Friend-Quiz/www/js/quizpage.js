var answeredQuestionCount = 0;
function quizpage() {
    if (unblockedContacts.users.length == 0) {
        takequiz();
        if (contactMode = "FACEBOOK" && facebookContacts.users.length == 0) {
            window.location.href="didtap://showalert?message=Unable to read the contacts.";

        } else if (contactMode = "MOBILE" && mobileContacts.users.length == 0) {
            window.location.href="didtap://showalert?message=Unable to read the contacts.";

        } else {
            window.location.href="didtap://showalert?message=You have blocked all the contacts.";

        }
    } else {
        document.bgColor = '#57c5f8';
        var quizpageIds = [ "displaycoinstext", "quizpage",
                           "quizpageshowcoins", "quizpageshowcoinstext", "myhome" ];
        showSections(quizpageIds);
        $("#quizpageshowcoinstext").html(myCoins + " Coins");
        if (questionCount >= 1000) {
            window.location.href="didtap://showalert?message=Reached today's limit.";
            takequiz();
        } else {
            nextQuiz();
        }
    }
}
function getRandom(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function nextQuiz() {
    document.bgColor = '#57c5f8';
    $("#quizpage").show();
    onNext();
}
var tempContactIndex;
function onNext() {
    var tempIndex = getRandom(0, questiondata.questions.length - 1);
    currentQuestion = questiondata.questions[tempIndex].question;
    currentQuestionId = questiondata.questions[tempIndex].questionId;
    tempContactIndex = getRandom(0, unblockedContacts.users.length - 1);
    currentNumber = unblockedContacts.users[tempContactIndex].number;
    currentQuestion = currentQuestion.replace('`````',
                                              unblockedContacts.users[tempContactIndex].username.fontcolor("#ff0000"));
    $("#question").html(currentQuestion);
    $("#displaycoinstext").html(myCoins + " Coins");
}
function updateAnswerCount(){
    if(answeredQuestionCount >= 10){
        answeredQuestionCount = 0;
        var answerIncentiveData = {
            "deviceID" : deviceId,
            "number" : currentLoggedId
        };
        Zepto.ajax({
                   type : 'POST',
                   url : amazonurl + "/web/deviceDetails/updateAnswerIncentives/"
                   + Math.random(),
                   data : JSON.stringify(answerIncentiveData),
                   success : function(data) {
                   }
                   });
        myCoins = myCoins + answerIncentives;
        $("#quizpageshowcoinstext").html(myCoins + " Coins");
    }
}
function onYes() {
    logEvent("Answered");
    answeredQuestionCount += 1;
    updateAnswerCount();
    var qdata = {
        "questionId" : currentQuestionId,
        "answeredAbout" : currentNumber,
        "answer" : "Yes",
        "deviceId" : deviceId,
        "answeredUserName" : currentLoggedUser,
        "answeredUserNumber" : currentLoggedId
    };
    blockUI();
    Zepto.ajax({
               type : 'POST',
               url : amazonurl + "/web/quiz/answered/yes/" + Math.random(),
               data : JSON.stringify(qdata),
               success : function(data) {
               }
               });
    myCoins = parseInt(myCoins) + parseInt(grantingCoins);
    $("#quizpageshowcoinstext").html(myCoins + " Coins");
    onNext();
    unblockUI();
    questionCount += 1;
}
function onNo() {
    logEvent("Answered");
    answeredQuestionCount += 1;
    updateAnswerCount();
    blockUI();
    var qdata = {
        "questionId" : currentQuestionId,
        "answeredAbout" : currentNumber,
        "answer" : "Yes",
        "deviceId" : deviceId,
        "answeredUserName" : currentLoggedUser,
        "answeredUserNumber" : currentLoggedId
    };
    blockUI();
    Zepto.ajax({
               type : 'POST',
               url : amazonurl + "/web/quiz/answered/no/" + Math.random(),
               data : JSON.stringify(qdata),
               success : function(data) {
               }
               });
    myCoins = parseInt(myCoins) + parseInt(grantingCoins);
    $("#quizpageshowcoinstext").html(myCoins + " Coins");
    onNext();
    unblockUI();
    questionCount += 1;
}
function onSkip() {
    logEvent("Skipped");
    questionCount += 1;
    onNext();
}
function blockUser() {
    Zepto.post(amazonurl + "/web/blockUser/" + currentLoggedId + "/"
               + currentNumber + "/" + Math.random());
    unblockedContacts.users.splice(tempContactIndex, 1);
    if (unblockedContacts.users.length == 0) {
        takequiz();
        window.location.href="didtap://showalert?message=You have blocked all the contacts.";
    } else {
        questionCount += 1;
        onNext();
    }
}