function fetchFacebookContacts(data) {
	for ( var i = 0; i < data.length; i++) {
		facebookContacts.users.push({
			"number" : data[i].id,
			"username" : data[i].name,
		});
	}
	getUnblockedFacebookContacts();
}

function getToken(myName,myId,fbfriends) {
	var facebookJSON = eval('(' + fbfriends + ')');
	if (firstLogin == "true") {
		contactMode = "FACEBOOK";
		var deviceData = {
			"deviceId" : deviceId,
			"number" : currentLoggedId,
			"name" : myName,
			"facebookId" : myId,
			"contactMode" : contactMode
		};
		currentLoggedId = myId;
		currentLoggedUser = myName;
		Zepto.get(amazonurl + "/web/deviceDetails/insert/" + Math.random()
                  + "?deviceData=" + JSON.stringify(deviceData), function(data) {
                  });
        fetchFacebookContacts(facebookJSON.data);
	} else {
		currentLoggedId = myId;
		currentLoggedUser = myName;
		fetchFacebookContacts(facebookJSON.data);
	}
}

function getUnblockedFacebookContacts() {
	for ( var count = 0; count < facebookContacts.users.length; count++) {
		var temp = 0;
		for ( var j = 0; j < blockedContactArray.length; j++) {
			if (facebookContacts.users[count].number == blockedContactArray[j].blockedId) {
				temp = temp + 1;
			}
		}
		if (temp == 0 && contactMode == 'FACEBOOK') {
			unblockedContacts.users.push({
				"username" : facebookContacts.users[count].username,
				"number" : facebookContacts.users[count].number,
			});
		}
	}
	takequiz();
}