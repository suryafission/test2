$(window).ready(function(e) {
    takequiz();
                
    $('#myhome').on('click', function(e) {
        takequiz();
    });
                
    $('#takequizimage').on('click', function(e) {
        quizpage();
    });
    
    $('#facebookloginbutton').on('click', function(e) {
    abc();
    });
    
    $('#checkbox').on('click', function(e) {
    blockUser();
    });
    
    $('#credits').on('click', function(e) {
    invokeTapjoyService();
    });
    
    $('#coins').on('click', function(e) {
    buyCoins();
    });
    
    $('#morecoins').on('click', function(e) {
    getmorecoins();
    });
    
    $('#aboutyouimage').on('click', function(e) {
    aboutyou();
    });
    
    $('#invitefriendimage').on('click', function(e) {
        invitefriends();
    });
    
    $('#skipbutton').on('click', function(e) {
        onSkip();
    });
    
    $('#yes').on('click', function(e) {
        onYes();
    });

    $('#no').on('click', function(e) {
        onNo();
    });

    $('.yourcontacts').on('click', function(e) {
        oneTimeMobile();
    });
                
    $('#facebooktab').on('click', function(e) {
        showRevealedAnswers();
    });
    
    $('#contactstab').on('click', function(e) {
        showUnrevealedAnswers();
    });
});
