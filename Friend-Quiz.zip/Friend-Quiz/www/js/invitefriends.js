function invitefriends() {
	document.bgColor = '#ff6f4f';
	showSections([ "invitefriends", "quizpageshowcoins",
			"quizpageshowcoinstext", "myhome" ]);
	$("#invitefriendsshowcoinstext").text(myCoins + " Coins");
    $("#quizpageshowcoinstext").text(myCoins + " Coins");
	if (contactMode == "FACEBOOK") {
		showFacebookContacts();
	} else if (contactMode == "MOBILE") {
		showMobileContacts();
	}
};
function showFacebookContacts() {
	$("#whitebox").empty();
    if (facebookContacts.users.length == 0) {
        $("#whitebox").text(
                "Please login with Facebook to view the contacts");
    } else {
        if (contactMode == "FACEBOOK") {
            $("#whitebox").empty();

            for ( var i = 0; i < unblockedContacts.users.length; i++) {
                var fdivTag = document.createElement("div");
                fdivTag.id = i;
                fdivTag.className = "MobileContact";
                fdivTag.setAttribute("align", "left");
                fdivTag.style.margin = "3px";
                fdivTag.innerHTML = "<span id=\"contactname\">"
                        + unblockedContacts.users[i].username
                        + "</span><span class=\"invite\" id="
                        + unblockedContacts.users[i].number
                        + " onclick=\"inviteFrnd(this.id,'FACEBOOK')\"></span>";
                document.getElementById("whitebox").appendChild(fdivTag);
            }
        } else {
            $("#whitebox").empty();
            for ( var i = 0; i < facebookContacts.users.length; i++) {
                var fdivTag = document.createElement("div");
                fdivTag.id = i;
                fdivTag.className = "MobileContact";
                fdivTag.setAttribute("align", "left");
                fdivTag.style.margin = "3px";
                fdivTag.innerHTML = "<span id=\"contactname\">"
                        + facebookContacts.users[i].username
                        + "</span><span class=\"invite\" id="
                        + facebookContacts.users[i].number
                        + " onclick=\"inviteFrnd(this.id,'FACEBOOK')\"></span>";
                document.getElementById("whitebox").appendChild(fdivTag);
            }
        }
    }
}

function showMobileContacts() {
    $("#quizpageshowcoinstext").text(myCoins + " Coins");
	if (mobileContacts.users.length == 0) {
        $("#whitebox").text("Unable to read the contacts");
    } else {
        if (contactMode == "MOBILE") {
            $("#whitebox").empty();
            for ( var i = 0; i < unblockedContacts.users.length; i++) {
                var fdivTag = document.createElement("div");
                fdivTag.id = i;
                fdivTag.className = "MobileContact";
                fdivTag.setAttribute("align", "left");
                fdivTag.style.margin = "3px";
                if (invitedNumbers.indexOf(unblockedContacts.users[i].number) != -1) {
                    fdivTag.innerHTML = "<span id=\"contactname\">"
                        + unblockedContacts.users[i].username
                        + "</span><span class=\"invite-pressed\" id="
                        + unblockedContacts.users[i].number
                        + ">Invited</span>";
                } else {
                    fdivTag.innerHTML = "<span id=\"contactname\">"
                        + unblockedContacts.users[i].username
                        + "</span><span class=\"invite\" id="
                        + unblockedContacts.users[i].number
                        + " onclick=\"inviteFrnd(this.id,'MOBILE')\"></span>";
                }
                document.getElementById("whitebox").appendChild(fdivTag);
            }
        } else {
            //This will not call since we diabled facebook
            $("#whitebox").empty();
            for ( var i = 0; i < mobileContacts.users.length; i++) {
                var mdivTag = document.createElement("div");
                mdivTag.id = i;
                mdivTag.className = "MobileContact";
                mdivTag.setAttribute("align", "left");
                mdivTag.style.margin = "3px";
                mdivTag.innerHTML = "<span  id=\"contactname\">"
                        + mobileContacts.users[i].username
                        + "</span><span class=\"invite\"id="
                        + mobileContacts.users[i].number
                        + " onclick=\"inviteFrnd(this.id, 'MOBILE')\"></span>";
                document.getElementById("whitebox").appendChild(mdivTag);
            }
        }
    }
}
// Function to send invitation(MOBILE/FACEBOOK)
function inviteFrnd(id, mode) {
    invitedNumbers.push(id);
    document.getElementById(id).className = "invite-pressed";
    logEvent(currentLoggedId +" sent invitation to "+id);
    saveInvitation(id);
    window.location.href='didtap/invite?id='+id+',mode='+mode+',myId='+currentLoggedId+',incentives='+inviteIncentives;
    showMobileContacts();
    if(numberOfInvitations >= 5){
        numberOfInvitations=0;
        //window.location.href='didtap/tapjoyCPEInvites';
        alert(numberOfInvitations);
    } else{
        numberOfInvitations=numberOfInvitations+1;
    }
}

//Function to save the invitation at server
function saveInvitation(id) {
    var invitationData = {
        "invitedNumber" : currentLoggedId,
        "invitingNumber" : id
    };
    Zepto.ajax({
               type : "POST",
               url : amazonurl + '/web/invitation/insertNewInvitation/'+Math.random(),
               data : 'invitationData=' + JSON.stringify(invitationData),
               success : function() {
               }
               });
}
