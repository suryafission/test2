//Callback to set FacebookFriends data
function getToken(access) {
	var string = access.split('`').join('"');
	var facebookJSON = eval('(' + string + ')');
	if (firstLogin == "true") {
		contactMode = "FACEBOOK";
		var deviceData = {
			"deviceId" : deviceId,
			"number" : currentLoggedId,
			"name" : facebookJSON.name,
			"facebookId" : facebookJSON.id,
			"contactMode" : contactMode
		};
		currentLoggedId = facebookJSON.id;
		currentLoggedUser = facebookJSON.name;
		Zepto.get(amazonurl + "/web/deviceDetails/insert/" + Math.random()
				+ "?deviceData=" + JSON.stringify(deviceData), function(data) {
			fetchFacebookContacts(facebookJSON.friends);
		});
	} else {
		currentLoggedId = facebookJSON.id;
		currentLoggedUser = facebookJSON.name;
		fetchFacebookContacts(facebookJSON.friends);
	}
}

// Call to set the updated coins on push notification
function setCoins(updatedCoins) {
	myCoins = parseInt(myCoins) + parseInt(updatedCoins);
	$('#quizpageshowcoinstext').text(myCoins + " Coins");
	$('#displaycoinstext').text(myCoins + " Coins");
}

// Callback to set the mobileNumber entered by the user
function getMobile(number) {
	currentLoggedId = number;
	myCoins = 4;
	promptName();
}