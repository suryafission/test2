var validationCallback = function(data) {
	unblockUI();
	collectTemplates(data);
    grantingCoins = parseInt(data.grantingCoins);
    deductingCoins = parseInt(data.deductingCoins);
    coinsRatioArray = data.coinsRatioArray;
    inviteIncentives = data.inviteIncentives;
    answerIncentives = data.answerIncentives;
    invitedNumbers = data.invitedNumbers;
    tapjoyEnabled = data.tapjoyEnabled;
    verified = data.verified;
    if(tapjoyEnabled == "0"){
        $('#credits').hide();
    }
    $('#inviteIncentiveDiv').text(inviteIncentives);
    $('#answerIncentiveDiv').text(answerIncentives);
    $('#grantingDiv').text(grantingCoins);
    $('#noq').text('10');
	if (data.result == "success") {
		firstLogin = "false";
		currentLoggedId = data.number;
		currentLoggedUser = data.name;
		myCoins = data.noc;
		contactMode = data.contactMode;
		$("#displaycoinstext").html(myCoins + " Coins");
		$("#quizpageshowcoinstext").html(myCoins + " Coins");
		
        getUnblockedMobileContacts();
        //commented to diable facebook
        /*if (contactMode == "FACEBOOK") {
            abc();
        } else if (contactMode == "MOBILE") {
            getUnblockedMobileContacts();
        }*/
	} else if (data.result == "failure") {
        myCoins = parseInt(data.defaultCoins);
		$("#displaycoinstext").html(myCoins + " Coins");
		$("#quizpageshowcoinstext").html(myCoins + " Coins");
        //Commented to disable facebook
		//promptPage();
        
        //Commented following line for 1.1
        //promptDetails();
        getUnblockedMobileContacts();
	}
}

function init(devId) {
    deviceId = devId;
	facebookContacts.users = [];
	blockUI();
	var takequizIds = [ "takequiz" ];
	showSections(takequizIds);
	validateDevice(deviceId, validationCallback);
}

function validateDevice(deviceId, callback) {
	Zepto.getJSON(amazonurl + "/web/deviceDetails/validate/" + deviceId + "/"
			+ Math.random(), callback);
}

function collectTemplates(data) {
	questiondata.questions = [];
	var questionArray = data.templates;
	blockedContactArray = data.blockedConatcts;
	if (contactMode == 'MOBILE') {
		unblockedContacts.users = [];
	}
	for ( var count = 0; count < questionArray.length; count++) {
		questiondata.questions.push({
			"question" : questionArray[count].question,
			"questionId" : questionArray[count].questionId
		});
	}
}

function promptPage() {
	document.bgColor = '#ff9e3d';
	showSections([ "loginpage" ]);
}

function setUserDetails(mobileNumber, userName){
    currentLoggedId = mobileNumber.split(')').join('');
    currentLoggedId = currentLoggedId.split('(').join('');
    currentLoggedId = currentLoggedId.split('-').join('');
    currentLoggedId = currentLoggedId.substring(currentLoggedId.length - 10, currentLoggedId.length);
    if(currentLoggedId.length<10){
        promptDetails();
    }
    
    currentLoggedUser = userName;
	if (currentLoggedUser == '' || currentLoggedUser == null || currentLoggedUser.length<3) {
		promptDetails();
	} else{
        oneTimeMobile();
    }
}

function promptDetails(){
    window.location.href='didtap://details';
}