function getmorecoins() {
    showButtons();
	document.bgColor = '#ae7dd2';
	showSections([ "getmorecoins", "quizpageshowcoins",
			"quizpageshowcoinstext", "myhome" ]);
	$("#getmorecoinsshowcoinstext").html(myCoins + " Coins");
}

//Function to invoke Tapjoy screen
function invokeTapjoyService() {
	window.location.href='didTap://button2';
}
function showButtons() {
    $('#coins20').text(coinsRatioArray[0].coins + " coins for " + coinsRatioArray[0].currency + "$");
     $('#coins80').text(coinsRatioArray[1].coins + " coins for " + coinsRatioArray[1].currency + "$");
    $('#coins120').text(coinsRatioArray[2].coins + " coins for " + coinsRatioArray[2].currency + "$");
    $('#coins250').text(coinsRatioArray[3].coins + " coins for " + coinsRatioArray[3].currency + "$");
    $('#coins500').text(coinsRatioArray[4].coins + " coins for " + coinsRatioArray[4].currency + "$");
                       
    
}

//Function to invoke in-app purchase functionality
function buyACoins(){
    window.location.href='didtap://inappa';
}
function buyBCoins(){
    window.location.href='didtap://inappb';
}

function buyCCoins(){
    window.location.href='didtap://inappc';
}

function buyDCoins(){
    window.location.href='didtap://inappd';
}

function buyECoins(){
    window.location.href='didtap://inappe';
}