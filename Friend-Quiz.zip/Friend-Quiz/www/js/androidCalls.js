// Function to add Flurry Log
function logEvent() {
	ANDROIDHTML.logEvent('New user logged in');
}

// Function to add Flurry Log
function logEvent(message) {
	ANDROIDHTML.logEvent(message);
}

// Function to prompt the user for the mobile number
function promptMobileNumber() {
	ANDROIDHTML.promptMobileNumber();
}

// Function to getDeviceId of the android device
function getDeviceId() {
	deviceId = ANDROIDHTML.getDeviceId();
}

// Function to get the version of the device
function getVersion() {
	currentVersion = ANDROIDHTML.getVersion();
}

// Function to invoke Facebook SDK
abc = function() {
	ANDROIDHTML.facebookCall();
}

// Function to send invitation(MOBILE/FACEBOOK)
function inviteFrnd(id, mode) {
	ANDROIDHTML.inviteFriend(id, mode);
}

// Function to get the mobile contacts
function getContacts() {
	return ANDROIDHTML.getContacts();
}