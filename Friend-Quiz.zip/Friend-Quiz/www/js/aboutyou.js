var currentPage = "UNREVEALED";

function aboutyou() {
    isClicked = "NO";
	document.bgColor = '#4987ff';
    currentPage = "UNREVEALED";
	showSections([ "aboutyou", "quizpageshowcoins", "quizpageshowcoinstext",
			"myhome" ]);
    $('#higherVersionDiv-revealed').empty();
    $('#higherVersionDiv-unrevealed').empty();
	$("#quizpageshowcoinstext").html(myCoins + " Coins");
	$("#home-coins").css('background-color', '#4987ff');
    
    /* 1.1 Changes start*/
    if(verified != "" && verified != "NO"){
        getAnswersAboutMe();
    } else{
        if(promptedDetails == 'NO'){
            promptedDetails = 'YES';
            promptDetails();
        } else{
            window.location.href="didtap://showalert?message=Your mobile number is under verification";
        }
        takequiz();
    }
    /* 1.1 Changes end*/
}

function logEvent(message){
    window.location.href='didtap://logevent?eventMessage='+message;
}

function showRevealedAnswers(){
    currentPage = "REVEALED";
    document.getElementById('contactstab').className = "facebooktab-inactive";
    document.getElementById('facebooktab').className = "contactstab";
    $('#higherVersionDiv-revealed').show();
    $('#higherVersionDiv-unrevealed').hide();
    if(revealedAnswers.users.length == 0){
        $('#higherVersionDiv-revealed').text("There are no questions revealed by you");
    }
    unblockUI();
}

function showUnrevealedAnswers(){
    currentPage = "UNREVEALED";
    document.getElementById('contactstab').className = "facebooktab";
    document.getElementById('facebooktab').className = "contactstab-inactive";
    $('#higherVersionDiv-revealed').hide();
    $('#higherVersionDiv-unrevealed').show();
    if(unrevealedAnswers.users.length == 0){
        $('#higherVersionDiv-unrevealed').text("There are no questions answered about you");
    }
    unblockUI();
}

function pushAnswerEntry(targetDivId, myAnswers){
    var j = myAnswers.users.length - 1;
    var divTag = document.createElement("div");
    divTag.align = "center";
    divTag.id = "answer" + j;
    divTag.className = "answerDiv";
    if (myAnswers.users[j].revealed == "YES") {
        divTag.innerHTML = "<span id=\"aboutuquestion\">"
        + myAnswers.users[j].question
        + "</span><br/><span id=\"revealeddata\">"
        + myAnswers.users[j].answeredUser
        +"</span>";
    } else if (myAnswers.users[j].revealed == "NO") {
        divTag.onclick = function(){
            blockUI();
            if(isClicked == "NO"){
                isClicked = "YES";
                if(myCoins < deductingCoins){
                    window.location.href="didtap://showalert?message=You dont have enough coins to reveal answer.";
                    setTimeout(function(){getmorecoins();},1200);
                    unblockUI();
                } else{
                    findUser(this.id);
                }
            } else{
                unblockUI();
            }
        };
        
        divTag.innerHTML = myAnswers.users[j].question
        + "<br/><div id=\"find\"><div id=\"findouttext\">Find out who says for "+deductingCoins+" coins</div></div>";
    }
    $('#'+targetDivId).append(divTag);
}

function getAnswersAboutMe() {
	blockUI();
	Zepto.getJSON(amazonurl + "/web/get/answersAboutMe/" + currentLoggedUser
			+ "/" + currentLoggedId + "/" + Math.random(), function(data) {
		unblockUI();
        revealedAnswers.users = [];
        unrevealedAnswers.users = [];
		if (data.users.length == 0) {
			$('#higherVersionDiv-unrevealed').text("There are no questions answered about you<br><br>"+
                                "<input type='button' value='Invite your friends' onclick='invitefriends();'/>");
		} else {
			for ( var i = 0; i < data.users.length; i++) {
                  var userName = data.users[i].userAnswered;
                  if(contactNumbers.indexOf(data.users[i].answeredMobile) != -1){
                        userName = contactNames[contactNumbers.indexOf(data.users[i].answeredMobile)];
                  }
                  if(data.users[i].revealed == "YES"){
                        revealedAnswers.users.push({
                            "answerId" : data.users[i].answerId,
                            "answeredUser" : userName,
                            "answer" : data.users[i].answer,
                            "question" : data.users[i].question,
                            "revealed" : data.users[i].revealed,
                            "answeredMobile" : data.users[i].answeredMobile
                        });
                        pushAnswerEntry('higherVersionDiv-revealed',revealedAnswers);
                  } else{
                        unrevealedAnswers.users.push({
                            "answerId" : data.users[i].answerId,
                            "answeredUser" : userName,
                            "answer" : data.users[i].answer,
                            "question" : data.users[i].question,
                            "revealed" : data.users[i].revealed,
                            "answeredMobile" : data.users[i].answeredMobile
                        });
                        pushAnswerEntry('higherVersionDiv-unrevealed',unrevealedAnswers);
                  }
			}
			displayAnswers();
		}
	});
}
function displayAnswers() {
    $("#quizpageshowcoinstext").html(myCoins + " Coins");
    $('#higherVersionDiv-unrevealed').hide();
    $('#higherVersionDiv-revealed').hide();
    showUnrevealedAnswers();
}
function findUser(id) {
	var clickOn = id.substring(id.indexOf('answer') + 6, id.length);
	var findOutData = {
        "deviceId" : deviceId,
        "answerId" : unrevealedAnswers.users[clickOn].answerId,
        "userId" : currentLoggedId
    };
    Zepto.post(amazonurl + "/web/findout/" + Math.random(),JSON.stringify(findOutData),
            function() {
               logEvent("Revealed");
               myCoins = parseInt(myCoins) - parseInt(deductingCoins);
               $("#quizpageshowcoinstext").html(myCoins + " Coins");
               isClicked = "NO";
               unrevealedAnswers.users[clickOn].revealed = "YES";
               refreshPage();
            });
}

function refreshPage(){
    $('#higherVersionDiv-unrevealed').empty();
        for(var j=0;j<unrevealedAnswers.users.length;j++){
            var divTag = document.createElement("div");
            divTag.align = "center";
            divTag.id = "answer" + j;
            divTag.className = "answerDiv";
            if (unrevealedAnswers.users[j].revealed == "YES") {
                divTag.innerHTML = "<span id=\"aboutuquestion\">"
                    + unrevealedAnswers.users[j].question
                    + "</span><br/><span id=\"revealeddata\">"
                    + unrevealedAnswers.users[j].answeredUser
                    +"</span>";
            } else if (unrevealedAnswers.users[j].revealed == "NO") {
                divTag.onclick = function(){
                    blockUI();
                    if(isClicked == "NO"){
                        isClicked = "YES";
                        if(myCoins < deductingCoins){
                            window.location.href="didtap://showalert?message=You dont have enough coins to reveal answer.";
                            setTimeout(function(){getmorecoins();},1200);
                            unblockUI();
                        } else{
                            findUser(this.id);
                        }
                    } else{
                        unblockUI();
                    }
                };
        
                divTag.innerHTML = unrevealedAnswers.users[j].question
                    + "<br/><div id=\"find\"><div id=\"findouttext\">Find out who says for "+deductingCoins+" coins</       div></div>";
            }
            $('#higherVersionDiv-unrevealed').append(divTag);
        }
    $('#higherVersionDiv-unrevealed').append('<br/>');
    unblockUI();
}

