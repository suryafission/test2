function displayMobileContacts() {
	var str = ANDROIDHTML.getContacts();
	getAllSelectedMobileContacts(str);
}
function getAllSelectedMobileContacts(str) {
	var jsonContacts = eval('(' + str + ')');
	mobileContacts.users = [];
	for ( var i = 0; i < jsonContacts.users.length; i++) {
		var number = jsonContacts.users[i].number;
		number = number.substring(number.length - 10, number.length);
		mobileContacts.users.push({
			"username" : jsonContacts.users[i].name,
			"number" : number,
			"os" : jsonContacts.users[i].os
		});
	}
	getUnblockedMobileContacts();
}
function getUnblockedMobileContacts() {
	for ( var count = 0; count < mobileContacts.users.length; count++) {
		var temp = 0;
		for ( var j = 0; j < blockedContactArray.length; j++) {
			if (mobileContacts.users[count].number == blockedContactArray[j].blockedId) {
				temp = temp + 1;
			}
		}
		if (temp == 0 && contactMode == 'MOBILE') {
			unblockedContacts.users.push({
				"username" : mobileContacts.users[count].username,
				"number" : mobileContacts.users[count].number,
				"os" : mobileContacts.users[count].os
			});
		}
	}
	takequiz();
}