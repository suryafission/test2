var amazonurl = "http://ec2-23-23-3-159.compute-1.amazonaws.com:8080";
var facebookContacts = {
	"users" : [ {
		"number" : "",
		"username" : "",
	} ]
};
facebookContacts.users = [];
var unselectURL = "file:///android_asset/www/images/unselected.png";
var selectURL = "file:///android_asset/www/images/selected.png";
var jsonobj = {
	"users" : [ {
		"username" : "",
		"number" : ""
	} ]
};
var currentLoggedUser = "dummy";
var currentLoggedId = "";
var questiondata = {
	"questions" : [ {
		"question" : "",
		"questionId" : ""
	} ]
};
var questionCount = 0;
var count = 0;
var mobileContacts = {
	"users" : [ {
		"username" : "",
		"number" : "",
		"os" : ""
	} ]
};
var myCoins = 0;
var access = null;
var deviceId = "";
var answers = {
	"users" : [ {
		"answerId" : "",
		"answeredUser" : "",
		"answer" : "",
		"question" : "",
		"revealed" : "",
		"answeredMobile" : ""
	} ]
};
var unrevealedAnswers = {
	"users" : []
};
var revealedAnswers = {
	"users" : []
};
var contactMode = "MOBILE";
var blockedList = [];
var unblockedContacts = {
	"users" : []
};
var contactNames = [];
var contactNumbers = [];
var currentQuestion;
var currentQuestionId;
var currentNumber;
var blockedContactArray;
var currentVersion;
var firstLogin = "true";
var deductingCoins;
var grantingCoins;
var coinsRatioArray;
var inviteIncentives;
var answerIncentives;
var invitedNumbers;
var isClicked = "NO";
var verified="";
var tapjoyEnabled = "";
var numberOfInvitations=0;
var promptedDetails = "NO";