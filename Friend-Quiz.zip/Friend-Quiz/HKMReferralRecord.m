#import "HKMReferralRecord.h"

@implementation HKMReferralRecord

@synthesize totalClickThrough, totalInvitee, invitationDate;

- (id) init {
	return self;
}

@end
