//
//  FQViewController.m
//  Friend-Quiz
//
//  Created by Ashish Kumar on 13/02/13.
//  Copyright (c) 2013 FriendsQuiz. All rights reserved.
//

#import "FQViewController.h"
#import "HKMLead.h"
#import <AddressBook/AddressBook.h>
#import "HKMDiscoverer.h"
#import "HKMOpenUDID.h"
#import "FQAppDelegate.h"
#import <QuartzCore/QuartzCore.h>
#import "SVProgressHUD.h"
#import "KGModal.h"
#import "JSONKit.h"


@interface FQViewController ()

@end




@implementation FQViewController
@synthesize updatedCoin,myDeviceToken,myContactString;
@synthesize  product = _product;
@synthesize wantedname,wantednumber,finalContacts,service;


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    NSLog(@"view did load");

 
    _myview=[[UIView alloc]initWithFrame:CGRectMake(self.view.bounds.origin.x, self.view.bounds.origin.y, self.view.bounds.size.width, self.view.bounds.size.height)];
    _myview.backgroundColor=[UIColor yellowColor];
    
//    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
//    {
//        CGSize result = [[UIScreen mainScreen] bounds].size;
//        if(result.height == 480)
//        {
//            // iPhone Classic
//
//            [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"loading@2x"]]];
//
//        }
//        if(result.height == 568)
//        {
//            // iPhone 5
//            _myview.backgroundColor=[UIColor yellowColor];
//            [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"loading@2x"]]];
//
//        }
//    }


    
    [_activityIndicator startAnimating];
    _htmlView.opaque = NO;
    _htmlView.backgroundColor = [UIColor clearColor];

    
  

    

    
    
    //flurry event
    [Flurry logEvent:@"app launched"];
    [DeepForestSDK logAction:@"app launched"];
    
    [[SKPaymentQueue defaultQueue]addTransactionObserver:self];
       
    
    if (ABAddressBookRequestAccessWithCompletion != NULL)   // we're on iOS 6
    {
        ABAddressBookRef addressBookRef = ABAddressBookCreateWithOptions(NULL, NULL);

    if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusNotDetermined) {
        ABAddressBookRequestAccessWithCompletion(addressBookRef, ^(bool granted, CFErrorRef error) {
            // First time access has been granted, add the contact
 [self localContacts];
        });
    }
    else if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusAuthorized) {
        // The user has previously given access, add the contact
 [self localContacts];
    }
    else {
         [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"320-480-splashscreen"]]];
        _htmlView.hidden = YES;
        UIAlertView *contactAlert = [[UIAlertView alloc]initWithTitle:@"Contact access was denied" message:@"Please go to Setting > General >Reset > Reset Location and privacy" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [contactAlert show];
        
    }  
    }
    else{
    
        [self localContacts];

    }
    
}


-(void)loadHtmlView{



    _htmlView.scrollView.scrollEnabled = YES;
    _htmlView.scalesPageToFit=NO;
    _htmlView.scrollView.showsHorizontalScrollIndicator=NO;
    _htmlView.scrollView.showsVerticalScrollIndicator= NO;
    _htmlView.scrollView.bounces = NO;
    
    
    NSURL *url = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"login" ofType:@"html" inDirectory:@"www"]];
    [_htmlView loadRequest:[NSURLRequest requestWithURL:url]];






}







-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
  
    
  
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(receiveTestNotification:)
                                                 name:@"updateCredit"
                                               object:nil];
    
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(receiveTestNotification:)
                                                 name:@"callMyCredit"
                                               object:nil];

    
    
       
    
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self callCreditService];

}


-(void)callCreditService{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://ec2-23-23-3-159.compute-1.amazonaws.com:8080/web/deviceDetails/fetchCoinsByDevice"]];
    
    [request setHTTPMethod:@"POST"];
    
    NSString *params =[NSString stringWithFormat:@"deviceId=%@",[HKMOpenUDID value]];
    
    
    
    
    
    NSData *data = [params dataUsingEncoding:NSUTF8StringEncoding];
    [request addValue:@"8bit" forHTTPHeaderField:@"Content-Transfer-Encoding"];
    [request addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request addValue:[NSString stringWithFormat:@"%i", [data length]] forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:data];
    
    
    
    [NSURLConnection connectionWithRequest:request delegate:self];
    


}

- (void) receiveTestNotification:(NSNotification *) notification
{
    // [notification name] should always be @"TestNotification"
    // unless you use this method for observation of other notifications
    // as well.
    
    [self callCreditService];
    
    
    if ([[notification name] isEqualToString:@"updateCredit"])
        NSLog (@"Successfully received the test notification!");
    
    if ([[notification name] isEqualToString:@"callMyCredit"]){
    
    
    }

}

-(void)updateCredits{
    
   // updatedCoin = [[NSUserDefaults standardUserDefaults]stringForKey:@"token"];

    [_htmlView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"replaceCoins('%@')", updatedCoin]];
    
    NSLog(@"coin req sent");
    NSLog(@"this is coin%@",updatedCoin);
    
    
    
    //----
    
    
    
    
    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





// webview delegate ======


- (void)webViewDidStartLoad:(UIWebView *)webView{
    

    
    
    //----------------------
    [_htmlView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"getUDID('%@')", [HKMOpenUDID value]]];
    NSLog(@"webview did start load");
    
    
    
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    NSLog(@"webViewDidFinishLoad");
    
    [_activityIndicator stopAnimating];

    
        
    

    
    NSLog(@"This is result :%@",myContactString);
    
    [_htmlView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"testMyContacts('%@')", myContactString]];
    [TestFlight passCheckpoint:myContactString];

    
   // NSLog(@"this is contact %@",[NSString stringWithFormat:@"testMyContacts('%@')", myContactString]);
    
  
    [_htmlView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"init('%@')", [HKMOpenUDID value]]];
    
   // [_htmlView stringByEvaluatingJavaScriptFromString:@"document.body.style.webkitTouchCallout='none';"];
    
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    //  NSLog(@"didFailLoadWithError %@",error);
}


- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    
    NSURL *url = [request URL];

    NSString *urlString = [url absoluteString];
    NSLog(@"%@  :: %i",urlString,urlString.length);
    
    
    NSRange range = [urlString rangeOfString:@"invite"];
    if  (range.length> 0){
        NSLog(@"GotIT");
        NSArray *substrings = [urlString componentsSeparatedByString:@"?"];
        NSString *reqString = [substrings objectAtIndex:1];
        NSLog(@"%@ " , reqString);
        NSArray *substrings2 = [reqString componentsSeparatedByString:@","];
        NSString *idString = [substrings2 objectAtIndex:0];
        NSString *modeString = [substrings2 objectAtIndex:1];
        NSString *myIdstring = [substrings2 objectAtIndex:2];
        NSString *inct = [substrings2 objectAtIndex:3];
        NSLog(@"THIS is ID: %@ , THIS is MODE :%@",idString,modeString);
        
        NSArray *substrings3 = [idString componentsSeparatedByString:@"id="];
        NSString *idValue = [substrings3 objectAtIndex:1];
        
        NSArray *substrings4 = [modeString componentsSeparatedByString:@"mode="];
        NSString *modeValue = [substrings4 objectAtIndex:1];
        
        NSArray *subsstring5 = [myIdstring componentsSeparatedByString:@"myId="];
        NSString *myIDstr = [subsstring5 objectAtIndex:1];
        NSLog(@"MYID :%@",myIDstr);
        
        NSArray *subsstring6 = [inct componentsSeparatedByString:@"incentives="];
        NSString *localInc = [subsstring6 objectAtIndex:1];
        
        updatedCoin = localInc;
        [self callCreditService];
                
        NSString *contactStr = [NSString stringWithFormat:@"+1%@",idValue];
        
        NSLog(@"THIS is ID:%@ , THIS is MODE:%@",contactStr,modeValue);
        if ([modeValue isEqualToString:@"MOBILE"]){
            NSMutableArray *phones = [NSMutableArray arrayWithCapacity:16];
            
            [phones addObject:contactStr];
            
            NSLog(@"phone %i",phones.count);
            [[HKMDiscoverer agent] newReferral:phones withName:nil useVirtualNumber:YES];
            [self inviteIncentives:myIDstr];
            [self callCreditService];
           
        }

    
    }
    
    NSRange Msgrange = [urlString rangeOfString:@"message"];
    if(Msgrange.length >0){
    
        NSArray *substrings = [urlString componentsSeparatedByString:@"?"];
        NSString *reqString = [substrings objectAtIndex:1];
        NSLog(@"%@ " , reqString);
        NSArray *substrings3 = [reqString componentsSeparatedByString:@"message="];
        NSString *idValue = [substrings3 objectAtIndex:1];
        NSString* message = [idValue stringByReplacingOccurrencesOfString:@"%20" withString:@" "];
        NSLog(@"Message :%@",message);
        
        UIAlertView *htmlAlert = [[UIAlertView alloc]initWithTitle:@"" message:message delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [htmlAlert show];
        


        
    }
    
    NSRange Flurryrange = [urlString rangeOfString:@"eventMessage"];
    
    if(Flurryrange.length >0){
        
        NSArray *substrings = [urlString componentsSeparatedByString:@"?"];
        NSString *reqString = [substrings objectAtIndex:1];
        NSLog(@"%@ " , reqString);
        NSArray *substrings3 = [reqString componentsSeparatedByString:@"eventMessage="];
        NSString *idValue = [substrings3 objectAtIndex:1];
        NSString* message = [idValue stringByReplacingOccurrencesOfString:@"%20" withString:@" "];
        NSLog(@"Message :%@",message);
        
        [Flurry logEvent:message];
        
        [DeepForestSDK logAction:message];
        
        
        
        
    }


    
    if([urlString isEqualToString:@"didtap://mobilecontacts"]){
        [_htmlView stopLoading];
        
        
        
    }
    
    else if([urlString isEqualToString:@"didtap://details"]){
        
        [_htmlView stopLoading];
        [self credentials];
        
        return NO;
    }

    
    else if([urlString isEqualToString:@"didtap://number"]){
        
        [_htmlView stopLoading];
        
        return NO;
    }
    
    else if([urlString isEqualToString:@"didtap://name"]){
        _number =YES;
       
        [_htmlView stopLoading];
        NSLog(@"Enter name alert");
        


        
        return NO;
    }


    else if([urlString isEqualToString:@"didtap://button2"]){
        [_htmlView stopLoading];
        NSLog(@"Tapjoy");
        //[self safariOffer:self];
        
        // [[UIApplication sharedApplication] openURL:url];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.tapjoy.com"]];
        
        
        return NO;
    }
    
    else if([urlString isEqualToString:@"didtap://inappa"]){
        [_htmlView stopLoading];
        NSLog(@"a");
        [self purchaseItem:@"one" :@"com.epicfunapps.inaap.FriendQuiz"];
        
                
        return NO;
    }
    else if([urlString isEqualToString:@"didtap://inappb"]){
        [_htmlView stopLoading];
        NSLog(@"b");
        //com.epicfunapps.60.FriendQuiz
        [self purchaseItem:@"two" :@"com.epicfunapps.60.FriendQuiz"];

       // [self purchaseItem2];
        
        
        return NO;
    }
    else if([urlString isEqualToString:@"didtap://inappc"]){
        [_htmlView stopLoading];
        NSLog(@"c");
        //com.epicfunapps.60.FriendQuiz
        [self purchaseItem:@"three" :@"com.epicfunapps.FQ120.FriendQuiz"];
        
        // [self purchaseItem2];
        
        
        return NO;
    }  else if([urlString isEqualToString:@"didtap://inappd"]){
        [_htmlView stopLoading];
        NSLog(@"d");
        //com.epicfunapps.60.FriendQuiz
        [self purchaseItem:@"four" :@"com.epicfunapps.FQ250.FriendQuiz"];
        
        // [self purchaseItem2];
        
        
        return NO;
    }  else if([urlString isEqualToString:@"didtap://inappe"]){
        [_htmlView stopLoading];
        NSLog(@"e");
        //com.epicfunapps.60.FriendQuiz
        [self purchaseItem:@"five" :@"com.epicfunapps.FQ500.FriendQuiz"];
        
        // [self purchaseItem2];
        
        
        return NO;
    }

  
       
  //  [self callCreditService];

    return YES;


}

-(void)credentials{

    //[self.view addSubview:];

    [[KGModal sharedInstance] showWithContentView:_myview andAnimated:YES];

    
    
	// Do any additional setup after loading the view, typically from a nib.
    _myfield=[[UITextField alloc]initWithFrame:CGRectMake(58, 120, 182, 43)];
    //  myfield.placeholder=@"enter mobile number";
   _myfield.borderStyle=UITextBorderStyleRoundedRect;
    [_myview addSubview:_myfield];
    _myfield.userInteractionEnabled=NO;
    
    
    _myfield2=[[UITextField alloc]initWithFrame:CGRectMake(50, 180, 200, 30)];
    _myfield2.placeholder=@"Enter your name";
    _myfield2.borderStyle=UITextBorderStyleRoundedRect;
    _myfield2.returnKeyType = UIReturnKeyDone;

    [_myview addSubview:_myfield2];
    _myfield2.delegate = self;

    _num1=[[UITextField alloc]initWithFrame:CGRectMake(65, 127, 50, 30)];
    _num2=[[UITextField alloc]initWithFrame:CGRectMake(120, 127, 50, 30)];
    _num3=[[UITextField alloc]initWithFrame:CGRectMake(175, 127, 60, 30)];
    _num1.borderStyle=UITextBorderStyleRoundedRect;
    _num2.borderStyle=UITextBorderStyleRoundedRect;
    _num3.borderStyle=UITextBorderStyleRoundedRect;
    [_myview addSubview:_num1];
    [_myview addSubview:_num2];
    [_myview addSubview:_num3];
    _num1.tag=100;
    _num2.tag=101;
    _num3.tag=103;
    _num1.delegate=self;
    _num2.delegate=self;
    _num3.delegate=self;
    [_num1 setKeyboardType:UIKeyboardTypeNumberPad];
    [_num2 setKeyboardType:UIKeyboardTypeNumberPad];
    [_num3 setKeyboardType:UIKeyboardTypeNumberPad];

    
    
    _mylabel=[[UILabel alloc]initWithFrame:CGRectMake(20, 40, 270, 60)];
    _mylabel.font=[UIFont italicSystemFontOfSize:14];
    _mylabel.text=@"Your True Mobile Number Will Help Us Find Out What Your Friends are Saying About You!";
    _mylabel.numberOfLines=3;
    _mylabel.backgroundColor=[UIColor clearColor];
    [_myview addSubview:_mylabel];
    
    _mybutton1=[UIButton buttonWithType:UIButtonTypeCustom];
    [_mybutton1 setImage:[UIImage imageNamed:@"join-me"] forState:UIControlStateNormal];
    _mybutton1.frame=CGRectMake(125, 260,60,40);
    [_mybutton1 setTitle:@"Join" forState:UIControlStateNormal];
    [_myview addSubview:_mybutton1];
    [_mybutton1 addTarget:self action:@selector(clearmethod) forControlEvents:UIControlEventTouchUpInside];


}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [[KGModal sharedInstance] endEditing:YES];
}

-(void)clearmethod
{
    if (_num3.text.length + _num2.text.length +_num1.text.length<10) {
        UIAlertView *warning=[[UIAlertView alloc]initWithTitle:@"Incorrect Mobile Number" message:@"Enter Your Complete Mobile Number" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [warning show];
    }else if ((_num1.text!=NULL)&& (_num2.text!=NULL)&&(_num3.text!=NULL)&&(_myfield2.text!=NULL)) {
        NSMutableString *final=[NSMutableString stringWithFormat:@"%@",_num1.text];
        [final appendString:_num2.text];
        [final appendString:_num3.text];
        NSLog(@"this is no : %@ this is name : %@",final,_myfield2.text);
        NSLog(@"credential :%@",[NSString stringWithFormat:@"setUserDetails('%@','%@')",final,_myfield2.text]);
        [[HKMDiscoverer agent] verifyDevice:self forceSms:NO userName:_myfield2.text];
        

        [_htmlView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"setUserDetails('%@','%@')",final,_myfield2.text]];
       
//        [UIView setAnimationDelegate:self];
//        [UIView beginAnimations:nil context:NULL];
//        [UIView setAnimationDuration:0.5];
//        [UIView setAnimationCurve:UIViewAnimationCurveLinear];
//        self.myview.transform =
//        CGAffineTransformMakeTranslation (0,480);
//        [UIView commitAnimations];
//        [self.myview removeFromSuperview];
        
        [[KGModal sharedInstance]hideAnimated:YES];

    }
    else {
        UIAlertView *warning=[[UIAlertView alloc]initWithTitle:@"Empty Field" message:@"Please Enter Your Mobile Number and Name" delegate:self cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
        [warning show];
    }
    
//    double delayInSeconds = 2.0;
//    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
//    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
//        
//        
//        
//        [self callCreditService];
//        
//    });


    
}





- (void)textFieldDidEndEditing:(UITextField *)textField
{
        
    
    NSLog(@"new number:%@%@%@",_num1.text,_num2.text,_num3.text);
    
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSLog(@"hii --%@ ",textField.text);
    
    if(textField==_num1)
    {
        
        NSLog(@"%i",_num1.text.length);
        if (_num1.text.length>=3 && range.length==0)
        {
            //[_myTextField resignFirstResponder];
            // [tf1 resignFirstResponder];
            [_num2 becomeFirstResponder];
            _num2.text=string;
            return NO;
        }
    }
    if(textField==_num2)
    {
        if (_num2.text.length>=3  && range.length == 0){
            //[_tf1 resignFirstResponder];
            [_num3 becomeFirstResponder];
            _num3.text=string;
            return NO;
        }
    }
    if(textField==_num3)
    {
        if (_num3.text.length>=4 && range.length == 0){
            [_num3 resignFirstResponder];
            return NO;
        }
    }
    
    if(textField==_myfield2)
    {
    
    if([_myfield2.text isEqualToString:@"\n"]) {
        
        // Be sure to test for equality using the "isEqualToString" message
        
        [_myfield2 resignFirstResponder];
        
        // Return FALSE so that the final '\n' character doesn't get added
        
        return NO;
    }

    }
    
    
    
    return YES;

}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
    return YES;

}


// HookMobile goes here==========================@@@@@@@@@@
/*

- (void) discoverComplete {
    
    //[[HKMDiscoverer agent] verifyDevice:self forceSms:NO userName:nil];
    [[HKMDiscoverer agent] queryVerifiedStatus];

    
     [[HKMDiscoverer agent] queryLeads];
    
   // [[HKMDiscoverer agent] queryReferral];

    NSLog(@"discoverComplete");
    // discoverButton.enabled = YES;
   
    
   
    [[HKMDiscoverer agent] queryLeads];
    
    

}

- (void) discoverFailed {
    NSLog(@"discoverFailed");
    // discoverButton.enabled = YES;
   }




-(void)discoverPhoneContact{

   
        ABAddressBookRef ab = ABAddressBookCreate();
        if (ABAddressBookRequestAccessWithCompletion != NULL) {
            ABAddressBookRequestAccessWithCompletion(ab, ^(bool granted, CFErrorRef
                                                           error) {
                if (granted) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if ([[HKMDiscoverer agent] discover:0]) {
                            
                        }
                    });
                } else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        UIAlertView* alert = [[UIAlertView alloc] init];
                        alert.title = @"Not Authorized";
                        alert.message = @"You denied access to your addressbook.Please go to Settings / Privacy / Contacts and enable access for this app.";
                            [alert addButtonWithTitle:@"Dismiss"];
                        alert.cancelButtonIndex = 0;
                        [alert show];
                    });
                }
            });
        } else {
            // iOS 5
            if ([[HKMDiscoverer agent] discover:0]) {
            }
        }
    
   // [self showQuery];


}


*/


- (IBAction) query: (id)sender {
    // queryButton.enabled = NO;
    [[HKMDiscoverer agent] queryLeads];

}


- (void) queryComplete {
    
    NSLog(@"queryComplete");
   // [self showQuery];

}

- (void) queryFailed {

    
  }


/*

-(void)showQuery{
    

       
   
    

    NSMutableArray *leadArray = [[NSMutableArray alloc]init];
    
    
    
  //  NSDictionary *leadDic = [[[HKMDiscoverer agent]leads ] objectAtIndex:0];
    
    //NSLog(@"ALL leads array name :%@ oStype: %@ phone: %@ " ,[leadDic valueForKey:@"name"] ,[leadDic valueForKey:@"osType"], [leadDic valueForKey:@"phone"]);
    
    NSLog(@"hk count %i",[[HKMDiscoverer agent]leads ].count);
    
    
    
    
    NSArray *myarray = [UserDetail findAllObjects];
    NSLog(@"my array count  %i ",[myarray count]);
    
    for (id item in [[HKMDiscoverer agent]leads]){
        
        NSLog(@"Lead %@",[item valueForKey:@"name"]);
        
        if ([item valueForKey:@"name"]) {
            BOOL isStoredInOuterDatabase = NO;
          //  NSLog(@"%@",[item valueForKey:@"number"]);
            NSString *numberString = [NSString stringWithFormat:@"%@",[item valueForKey:@"phone"]];
            NSLog(@"%@",numberString);
            for (UserDetail *dbEntry in myarray )
            {
                if ([dbEntry.number  isEqualToString: numberString] ) {
                    isStoredInOuterDatabase = YES;
                    break;
            
            }
        
                
        }
            
            if (!isStoredInOuterDatabase) {

        NSDictionary * phoneData = [NSDictionary dictionaryWithObjectsAndKeys:[item valueForKey:@"name"], @"name",[item valueForKey:@"osType"], @"os",[item                                                                                                                                                               valueForKey:@"phone"],@"number",nil];
        NSLog(@"phone data :%@",phoneData);
        [leadArray addObject:phoneData];
        
        [UserDetail newObjectWithValues:phoneData];
            }
            
            else {
#ifdef DEBUG
                NSLog(@"user List with number %@ already exists!", [item valueForKey:@"phone"]);
#endif
            }
        
    }

    
    
    
    }
    
    
    NSArray *contactArray = [UserDetail findAllObjects];
    NSLog(@"Contact array count :%i",[contactArray count]);
    
    
    
    NSMutableString *contactStringarray = [[NSMutableString alloc]init];
    NSDictionary *contactList ;

    NSDictionary *contactDict ;
    int i = 0;
    for (id item in contactArray){
        contactDict = [contactArray objectAtIndex:i];
        i = i+1;
        NSLog(@"This contact dict %@",[contactDict valueForKey:@"name"]);
        NSLog(@"This contact dict %@",[contactDict valueForKey:@"os"]);
        NSLog(@"This contact dict %@",[contactDict valueForKey:@"number"]);
        NSString *nameString =[contactDict valueForKey:@"name"];
        NSString *osString = [contactDict valueForKey:@"os"];
        NSString *numString = [NSString stringWithFormat:@"%@",[contactDict valueForKey:@"number"]];
        
        if(i == [contactArray count]){
        
        [contactStringarray appendFormat:@"{\"name\":\"%@\",\"os\":\"%@\",\"number\":\"%@\"}",nameString,osString,numString];
        
        }
        else{
        [contactStringarray appendFormat:@"{\"name\":\"%@\",\"os\":\"%@\",\"number\":\"%@\"},",nameString,osString,numString];
        }
        contactList = [NSDictionary dictionaryWithObjectsAndKeys:nameString,@"name",osString,@"os",numString,@"number", nil];
        
    }
    NSLog(@"this is dictionary %@",contactList);

    
  //  myContactString= [NSString stringWithFormat:@"{\"users\":[%@]}",contactStringarray];
    
    
    NSLog(@"This is show Query %@",[NSString stringWithFormat:@"{\"users\":[%@]}",contactStringarray]);

    
       
    
}
*/

-(void)localContacts{
   
    finalContacts = [NSMutableArray array];
    wantedname= [[NSMutableArray alloc] init];
    wantednumber= [[NSMutableArray alloc] init];
    _wantedLastname = [[NSMutableArray alloc] init];

    
  
    addressBook = ABAddressBookCreate();

    if (!addressBook) {
        NSLog(@"opening address book");
    }
    
    /*
    ABRecordRef source = ABAddressBookCopyDefaultSource(addressBook);
    NSArray *thePeople = (NSArray*)CFBridgingRelease(ABAddressBookCopyArrayOfAllPeopleInSourceWithSortOrdering(addressBook, source, kABPersonSortByLastName));
    
    
    NSString *name;
    NSString *lastName;

    for (id person in thePeople)
    {
        name = (NSString *)CFBridgingRelease(ABRecordCopyValue(CFBridgingRetain(person), kABPersonFirstNameProperty));
        lastName = (NSString *)CFBridgingRelease(ABRecordCopyValue(CFBridgingRetain(person), kABPersonLastNameProperty));
        
       // NSLog(@"!!!!!! name ---> %@",name);
        ABMultiValueRef multi = ABRecordCopyValue(CFBridgingRetain(person), kABPersonPhoneProperty);
        int count1=ABMultiValueGetCount(multi);
      //  NSLog(@"%d",count1);
        if ([name length]>0 && count1!=0)
        {
            NSString *beforenumber = (NSString *)CFBridgingRelease(ABMultiValueCopyValueAtIndex(multi, 0));
         //   NSLog(@" contacts:%@",beforenumber );
            NSString* removed1=[beforenumber stringByReplacingOccurrencesOfString:@"-"withString:@""];
            NSString* removed2=[removed1 stringByReplacingOccurrencesOfString:@")"withString:@""];
            NSString* removed3=[removed2 stringByReplacingOccurrencesOfString:@" "withString:@""];
            NSString* removed4=[removed3 stringByReplacingOccurrencesOfString:@"("withString:@""];
            NSString* removed5=[removed4 stringByReplacingOccurrencesOfString:@"+"withString:@""];
            [wantedname addObject:name];
            [wantednumber addObject:removed5];
//            if (lastName.length >0){
//                [_wantedLastname addObject:lastName];
//            }
//            else{
//                [_wantedLastname addObject:@""];
//                NSLog(@"last name empty %@",lastName);
//
//            }
            
        }
        CFRelease(multi);
       
    }
    
    CFRelease(addressBook);
    CFRelease(CFBridgingRetain(thePeople));
    
    int i = 0;
    for (id item in wantednumber){
 NSString *name = [NSString stringWithFormat:@"%@",[wantedname objectAtIndex:i]];
        NSString *number = [wantednumber objectAtIndex:i];

        
     
        
        NSDictionary *contactDictionary = [NSDictionary dictionaryWithObjectsAndKeys:name, @"name",number, @"number",nil];
       
        [finalContacts addObject:contactDictionary];
        i =i+1;

      //  [self discoverComplete];

    
    }
   
    
    
    NSMutableString *jsonString = [NSString stringWithFormat:@"%@",[finalContacts JSONString]];
    
       
    NSLog(@"Final contacts: %@",finalContacts);
    [TestFlight passCheckpoint:jsonString];
    myContactString= [NSString stringWithFormat:@"{\"users\":%@}",jsonString];
   NSLog(@"Final contacts---- %@",myContactString);
   // [self discoverComplete];


    if (myContactString.length >0)
        
    {
        
        
        [self loadHtmlView];
        
        
    }
    
    else
    {
        
        UIAlertView *loadFailAlert = [[UIAlertView alloc]initWithTitle:@"Sorry" message:@"Server Down. Please try after sometime." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        
        [loadFailAlert show];
        
        
    }
    
    */
    
  
    
    CFArrayRef allPeople = ABAddressBookCopyArrayOfAllPeople(addressBook);
    CFIndex nPeople = ABAddressBookGetPersonCount(addressBook);
    
	for (int i=0;i < nPeople;i++) {
        NSMutableDictionary *dOfPerson=[NSMutableDictionary dictionary];
        
        ABRecordRef ref = CFArrayGetValueAtIndex(allPeople,i);
        
        //For username and surname
        ABMultiValueRef phones =CFBridgingRetain((__bridge NSString*)ABRecordCopyValue(ref, kABPersonPhoneProperty));
        CFStringRef firstName, lastName;
        firstName = ABRecordCopyValue(ref, kABPersonFirstNameProperty);
        lastName  = ABRecordCopyValue(ref, kABPersonLastNameProperty);
        
        

        
        
        
        if (lastName == NULL || CFStringGetLength(lastName)==0){
            
            NSString *nameString = (__bridge NSString *)firstName;
            
            
            NSString *finalName = [nameString stringByReplacingOccurrencesOfString:@"'" withString:@"`"];
            //finalName = [finalName stringByReplacingOccuranceOfString:@">" withString:@""];
            
            [dOfPerson setObject:[NSString stringWithFormat:@"%@", finalName] forKey:@"name"];
            NSLog(@"Last name null %@", lastName);
        }
        if (firstName == NULL || CFStringGetLength(firstName)==0){
            
            NSString * lastString = (__bridge NSString*)lastName;
            NSString *finalNameLast = [lastString stringByReplacingOccurrencesOfString:@"'" withString:@"`"];
            
            
            [dOfPerson setObject:[NSString stringWithFormat:@"%@", finalNameLast] forKey:@"name"];
            NSLog(@"First name null %@", firstName);

        }
        if ((firstName !=NULL)&&(lastName !=NULL) )
        {
            
            NSString *nameString = (__bridge NSString *)firstName;
            NSString * lastString = (__bridge NSString*)lastName;

            
            NSString *finalName = [nameString stringByReplacingOccurrencesOfString:@"'" withString:@"`"];
            
            
            
            
            NSString *finalNameLast = [lastString stringByReplacingOccurrencesOfString:@"'" withString:@"`"];
            
            
            
            
            
            NSLog(@"Full Name %@ %@",finalName, finalNameLast);
            
            
            
            

            [dOfPerson setObject:[NSString stringWithFormat:@"%@ %@", finalName, finalNameLast] forKey:@"name"];

        }
        
        
       
        
        //For Phone number
        NSString* mobileLabel;
        //for(CFIndex i = 0; i &lt; ABMultiValueGetCount(phones); i++) {
        for(CFIndex i = 0; i < ABMultiValueGetCount(phones); i++) {

            mobileLabel = (NSString*)CFBridgingRelease(ABMultiValueCopyLabelAtIndex(phones, i));
            if (mobileLabel != NULL){
            if([mobileLabel isEqualToString:(NSString *)kABPersonPhoneMobileLabel])
            {
                [dOfPerson setObject:(NSString*)CFBridgingRelease(ABMultiValueCopyValueAtIndex(phones, i)) forKey:@"number"];
            }
            else if ([mobileLabel isEqualToString:(NSString*)kABPersonPhoneMobileLabel])
            {
                [dOfPerson setObject:(NSString*)CFBridgingRelease(ABMultiValueCopyValueAtIndex(phones, i)) forKey:@"number"];
                break ;
            }
            
            }
            
            else{
            
             [dOfPerson setObject:@"" forKey:@"number"];
            }
            
            [finalContacts addObject:dOfPerson];
//            CFRelease(ref);
//            CFRelease(firstName);
//            CFRelease(lastName);
        }
      //  NSLog(@"array is %@",finalContacts);
    }

    
    NSString *contactDetailStr = [NSString stringWithFormat:@"count of contacts %i",[finalContacts count]];

    [TestFlight passCheckpoint:contactDetailStr];
    
    NSArray *copy = [finalContacts copy];
    
    NSInteger index = [copy count] - 1;
    
    for (id object in [copy reverseObjectEnumerator])
    {
        
        if ([finalContacts indexOfObject:object inRange:NSMakeRange(0, index)] != NSNotFound)
            
        {
            [finalContacts removeObjectAtIndex:index];
            
        }
        
        index--;
    }

    
    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"name" ascending:YES];
    NSArray* sortedArray=[finalContacts sortedArrayUsingDescriptors:[NSArray arrayWithObject:sort]];
    
    
    NSMutableString *jsonString = [NSString stringWithFormat:@"%@",[sortedArray JSONString]];
    
    
    NSLog(@"Final contacts: %@",finalContacts);
    [TestFlight passCheckpoint:jsonString];
    myContactString= [NSString stringWithFormat:@"{\"users\":%@}",jsonString];
    
    if (myContactString.length >0)
        
    {
        
        
        [self loadHtmlView];
        
        
    }
    
    else
    {
        
        UIAlertView *loadFailAlert = [[UIAlertView alloc]initWithTitle:@"Sorry" message:@"Server Down. Please try after sometime." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        
        [loadFailAlert show];
        
        
    }


}


/*
-(void)getFBFriends{

       

    
    FBRequest* myRequest = [FBRequest requestForMe];
    [myRequest startWithCompletionHandler: ^(FBRequestConnection *connection,
                                                  NSDictionary* myResult,
                                                  NSError *error) {
        
        
        
       // HKMSBJsonWriter *jsonWriterMY = [[HKMSBJsonWriter alloc] init];
        
        
         facebookMyName= [myResult valueForKey:@"name"];
        
        facebookMyID = [myResult valueForKey:@"id"];
        
        
        NSLog(@"name %@ id %@",facebookMyName,facebookMyID);
        
        
        FBRequest* friendsRequest = [FBRequest requestForMyFriends];
        [friendsRequest startWithCompletionHandler: ^(FBRequestConnection *connection,
                                                      NSDictionary* result,
                                                      NSError *error) {
            
            
            HKMSBJsonWriter *jsonWriter = [[HKMSBJsonWriter alloc] init];
            
            
            facebookFriendString = [jsonWriter stringWithObject:result];
            
            
            
            
            NSLog(@"this is friends %@",facebookFriendString);
            
            [_htmlView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"getToken('%@','%@','%@')",facebookMyName,facebookMyID,facebookFriendString]];
            
            
        }];

        
          }];

    
    if ((facebookFriendString.length >0) || (facebookMyName.length >0)){
    
        [[NSNotificationCenter defaultCenter]
         postNotificationName:@"facebook"
         object:nil
         userInfo:nil];
        

    
    }

 
    
    }

*/

//storekit

-(void)purchaseItem:(NSString *)creditStr :(NSString *)productIdt
{
    
    if ([SKPaymentQueue canMakePayments]){

    SKProductsRequest *request= [[SKProductsRequest alloc]
                                 initWithProductIdentifiers: [NSSet setWithObject:productIdt]];
    
  
        
        //
    request.delegate = self;
    [request start];
       _purchasedCoins = creditStr;
        
        NSLog(@"%@--%@",creditStr,productIdt);
        [SVProgressHUD showWithStatus:@"Connecting Store" maskType:SVProgressHUDMaskTypeGradient];
    }
    else{
    
        NSLog(@"Sorry not approved");
        [SVProgressHUD showErrorWithStatus:@"Sorry Not approved"];
    
    }

}




-(void)purchaseItem2{
    
    SKProductsRequest *request= [[SKProductsRequest alloc]
                                 initWithProductIdentifiers: [NSSet setWithObject: @"com.epicfunapps.60.FriendQuiz"]];
    
    request.delegate = self;
    [request start];
    
}

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response
{
    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    
    NSArray *myProduct = response.products;
    NSLog(@"%@",[[myProduct objectAtIndex:0] productIdentifier]);
    NSLog(@"%@",[[myProduct objectAtIndex:0] localizedTitle]);
    NSLog(@"%@",[[myProduct objectAtIndex:0] price]);
    NSLog(@"%@",[[myProduct objectAtIndex:0] localizedDescription]);

    
    
       
    //Since only one product, we do not need to choose from the array. Proceed directly to payment.
    
    SKPayment *newPayment = [SKPayment paymentWithProduct:[myProduct objectAtIndex:0]];
    [[SKPaymentQueue defaultQueue] addPayment:newPayment];
    //deep forest
    
    NSLog(@"This is response %@",response);
    
}

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    [SVProgressHUD dismiss];


    for (SKPaymentTransaction *transaction in transactions)
    {
        switch (transaction.transactionState)
        {
                
            case SKPaymentTransactionStatePurchasing:
                NSLog(@"purchasing transaction");
                
                break;
            case SKPaymentTransactionStatePurchased:
                [self completeTransaction:transaction];
                break;
           
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                break;
            case SKPaymentTransactionStateRestored:
                [self restoreTransaction:transaction];
            default:
                break;
        }
    }
}

- (void) goingTransaction: (SKPaymentTransaction *)transaction
{
    [SVProgressHUD showWithStatus:@"In progress" maskType:SVProgressHUDMaskTypeGradient];

    NSLog(@"purchasing transaction");
    [self completeTransaction:transaction];



}


- (void) completeTransaction: (SKPaymentTransaction *)transaction
{
    [SVProgressHUD dismiss];
    NSLog(@"Transaction Completed");
    // You can create a method to record the transaction.
    // [self recordTransaction: transaction];
    
    // You should make the update to your app based on what was purchased and inform user.
    // [self provideContent: transaction.payment.productIdentifier];
    
    // Finally, remove the transaction from the payment queue.
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    
    UIAlertView *purchased = [[UIAlertView alloc]initWithTitle:@"" message:@"You have successfully purchased." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [purchased show];
    
    //[self sendCoinsToserver];
    [self postPurchasedCoins:_purchasedCoins];
    
 

}

- (void) restoreTransaction: (SKPaymentTransaction *)transaction
{
    NSLog(@"Transaction Restored");
    // You can create a method to record the transaction.
    // [self recordTransaction: transaction];
    
    // You should make the update to your app based on what was purchased and inform user.
    // [self provideContent: transaction.payment.productIdentifier];
    
    // Finally, remove the transaction from the payment queue.
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
}

- (void) failedTransaction: (SKPaymentTransaction *)transaction
{
    if (transaction.error.code != SKErrorPaymentCancelled)
    {
        // Display an error here.
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Purchase Unsuccessful"
                                                        message:@"Your purchase failed. Please try again."
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    }
    
    // Finally, remove the transaction from the payment queue.
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    [[SKPaymentQueue defaultQueue] removeTransactionObserver:self];

}


-(void) connectionDidFinishLoading:(NSURLConnection*)connection {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"NSURLConnectionDidFinish" object:nil];
    NSLog(@"loading completed");
    
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    NSLog(@"received responce");
    NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)response;
    int code = [httpResponse statusCode];

    NSLog(@"status%i",code);
    if (code==200){
    
        [_htmlView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"updateCoinsOnPurchase('%@')", _purchasedCoins]];

        
    
    }
    
    

}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    NSLog(@"received data");
    
    NSError* error;
    NSDictionary* json = [NSJSONSerialization
                          JSONObjectWithData:data
                          
                          options:kNilOptions
                          error:&error];
    if ([json valueForKey:@"coins"]){
    NSLog(@"myCoins %@",[json valueForKey:@"coins"]);
    
    updatedCoin = [NSString stringWithFormat:@"%@",[json valueForKey:@"coins"]];
        
        [self updateCredits];
    }
}

-(void)postPurchasedCoins:(NSString*)purchased{

    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://ec2-23-23-3-159.compute-1.amazonaws.com:8080/web/deviceDetails/updateCoins"]];
    [request setHTTPMethod:@"POST"];
    
    NSString *params =[NSString stringWithFormat:@"deviceID=%@&identifier=%@",[HKMOpenUDID value],purchased];
    
    
    NSLog(@"%@",params);
    
    
    NSData *data = [params dataUsingEncoding:NSUTF8StringEncoding];
    [request addValue:@"8bit" forHTTPHeaderField:@"Content-Transfer-Encoding"];
    [request addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request addValue:[NSString stringWithFormat:@"%i", [data length]] forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:data];
    
    
    
    [NSURLConnection connectionWithRequest:request delegate:self];

    

}
-(void)inviteIncentives:(NSString*)incent{

    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://ec2-23-23-3-159.compute-1.amazonaws.com:8080/web/deviceDetails/updateCoinsOnInvite"]];
    [request setHTTPMethod:@"POST"];
    
    NSString *params =[NSString stringWithFormat:@"deviceID=%@&number=%@",[HKMOpenUDID value],incent];
    
    
    NSLog(@"%@",params);
    
    
    NSData *data = [params dataUsingEncoding:NSUTF8StringEncoding];
    [request addValue:@"8bit" forHTTPHeaderField:@"Content-Transfer-Encoding"];
    [request addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request addValue:[NSString stringWithFormat:@"%i", [data length]] forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:data];
    
    
    //[request setHTTPBody:[params dataUsingEncoding:NSISOLatin1StringEncoding]];
    
    [NSURLConnection connectionWithRequest:request delegate:self];


}





- (void)viewDidUnload {
    [self setActivityIndicator:nil];
    
    [super viewDidUnload];
}
@end
