//
//  main.m
//  Friend-Quiz
//
//  Created by Ashish Kumar on 13/02/13.
//  Copyright (c) 2013 FriendsQuiz. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "FQAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([FQAppDelegate class]));
    }
}
