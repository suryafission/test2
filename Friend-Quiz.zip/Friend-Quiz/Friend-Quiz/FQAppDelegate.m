//
//  FQAppDelegate.m
//  Friend-Quiz
//
//  Created by Ashish Kumar on 13/02/13.
//  Copyright (c) 2013 FriendsQuiz. All rights reserved.
//

#import "FQAppDelegate.h"
#import "HKMOpenUDID.h"
#import "TapjoyConnect.h"
#import "FQViewController.h"
#import "HKMDiscoverer.h"



@implementation FQAppDelegate


@synthesize myDeviceToken,isOPEN;

/*
 My Apps Custom uncaught exception catcher, we do special stuff here, and TestFlight takes care of the rest
 */
void HandleExceptions(NSException *exception) {
    NSLog(@"This is where we save the application data during a exception");
    // Save application data on crash
}
/*
 My Apps Custom signal catcher, we do special stuff here, and TestFlight takes care of the rest
 */
void SignalHandler(int sig) {
    NSLog(@"This is where we save the application data during a signal");
    // Save application data on crash
}







- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    
    //TestFlight--
    
    // installs HandleExceptions as the Uncaught Exception Handler
    NSSetUncaughtExceptionHandler(&HandleExceptions);
    // create the signal action structure
    struct sigaction newSignalAction;
    // initialize the signal action structure
    memset(&newSignalAction, 0, sizeof(newSignalAction));
    // set SignalHandler as the handler in the signal action structure
    newSignalAction.sa_handler = &SignalHandler;
    // set SignalHandler as the handlers for SIGABRT, SIGILL and SIGBUS
    sigaction(SIGABRT, &newSignalAction, NULL);
    sigaction(SIGILL, &newSignalAction, NULL);
    sigaction(SIGBUS, &newSignalAction, NULL);
    // Call takeOff after install your own unhandled exception and signal handlers

    [TestFlight takeOff:@"43fd39128981814e40ee3c7e81355834_MTcxODQ5MjAxMy0wMS0wNCAxMDo1MjozNy41MTA1MDY"];

    
  
    //HOOKMOBILE
    
    [HKMDiscoverer activate:@"35739ef5-531e-4173-aa22-d7ee44870aef"];
    
    
    
    //tapjoy
    
    [TapjoyConnect requestTapjoyConnect:@"01453a6c-fb1e-48d1-9a62-5b4697ad64c9"
							  secretKey:@"MBLPFsmftodRK5RKDyHR"
								options:[NSDictionary dictionaryWithObjectsAndKeys:
										 [NSNumber numberWithInt:TJCTransitionExpand], TJC_OPTION_TRANSITION_EFFECT,
										 [NSNumber numberWithBool:YES], TJC_OPTION_ENABLE_LOGGING,
										 // If you are not using Tapjoy Managed currency, you would set your own user ID here.
										 nil]];
    
    
    [TapjoyConnect setUserID:[HKMOpenUDID value]];
    
    
   
    
    
    NSString *userid =     [TapjoyConnect getUserID];
    NSLog(@"userid:  %@",userid);
    
    
    
    [DeepForestSDK initWithAppId:@"f1129ae2-78aa-4987-82e4-c316d859496e" secretKey:@"0ae1f74d467b2f866b4dc7259119e8bbef8e5321"];
    
    
    // Let the device know we want to receive push notifications
    [[UIApplication sharedApplication]registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound)];
    
    
//Flurry
    [Flurry startSession:@"47GZ3F4MH358SMGZW7P9"];
    
    
    
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
           {
                CGSize result = [[UIScreen mainScreen] bounds].size;
                if(result.height == 480)
                {
                    // iPhone Classic
        
                    [self.window setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"Default"]]];
        
                }
                if(result.height == 568)
                {
                    UIImage *backImage = [UIImage imageNamed:@"Default-568h@2x"];
                    UIImageView *backgroundImageView = [[UIImageView alloc] initWithImage:backImage];
                    [backgroundImageView setFrame:[[self window] bounds]];
                    [[self window] addSubview:backgroundImageView];
                    
                    
                    // iPhone 5
                  //  [self.window setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"login1@2x"]]];

        
                }
            }

    
    [self.window setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"Default"]]];
  
  //  [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    
   
    
    return YES;
}
							
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    
  //  [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];

}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];

}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    

//
    
    [[NSNotificationCenter defaultCenter]
     postNotificationName:@"callMyCredit"
     object:nil
     userInfo:nil];


   
    int badgeCount = [UIApplication sharedApplication].applicationIconBadgeNumber;
         [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    
    // [[UIApplication sharedApplication] cancelAllLocalNotifications];
    NSLog(@"Badge Count %i",badgeCount);
    
    
    
   // NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://ec2-23-23-3-159.compute-1.amazonaws.com:8080/web/badge/clear"]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://friendsgossip.epicfunapps.com/web/badge/clear"]];
    
   
    [request setHTTPMethod:@"POST"];
    
    NSString *params =[NSString stringWithFormat:@"deviceId=%@",[HKMOpenUDID value]];
    
    
    
    
    
    NSData *data = [params dataUsingEncoding:NSUTF8StringEncoding];
    [request addValue:@"8bit" forHTTPHeaderField:@"Content-Transfer-Encoding"];
    [request addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request addValue:[NSString stringWithFormat:@"%i", [data length]] forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:data];
    
    
    
    [NSURLConnection connectionWithRequest:request delegate:self];
    
    

    
    
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    
    [HKMDiscoverer retire];

}






- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    
    
    NSString *udid = [HKMOpenUDID value];
    
    // myDeviceToken = [[[[deviceToken description]stringByReplacingOccurrencesOfString:@"<"withString:@""]stringByReplacingOccurrencesOfString(angry)">" withString:@""stringByReplacingOccurrencesOfString: @" " withString: @""] ;
    
    
    myDeviceToken = [[[[deviceToken description]
                       stringByReplacingOccurrencesOfString:@"<"withString:@""]
                      stringByReplacingOccurrencesOfString:@">" withString:@""]
                     stringByReplacingOccurrencesOfString: @" " withString: @""];
    
    NSLog(@"DeviceToken :%@",myDeviceToken);
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://friendsgossip.epicfunapps.com/web/iOS/register"]];
    [request setHTTPMethod:@"POST"];
    
    NSString *params =[NSString stringWithFormat:@"deviceId=%@&deviceToken=%@",udid,myDeviceToken];
    
    
    
    
    
    NSData *data = [params dataUsingEncoding:NSUTF8StringEncoding];
    [request addValue:@"8bit" forHTTPHeaderField:@"Content-Transfer-Encoding"];
    [request addValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request addValue:[NSString stringWithFormat:@"%i", [data length]] forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:data];
    
    
    //[request setHTTPBody:[params dataUsingEncoding:NSISOLatin1StringEncoding]];
    
    [NSURLConnection connectionWithRequest:request delegate:self];
    
    
}

-(void) connectionDidFinishLoading:(NSURLConnection*)connection {
    NSLog(@"loading completed");
    
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    
    NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)response;
    int code = [httpResponse statusCode];
    NSLog(@"received responce %i",code);
    
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    NSLog(@"received data");
}





/**
 * Failed to Register for Remote Notifications
 */
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSString *str = [NSString stringWithFormat: @"Error: %@", error];
    NSLog(@"%@",str);
    
#if !TARGET_IPHONE_SIMULATOR
    
	NSLog(@"Error in registration. Error: %@", error);
    
#endif
}

/**
 * Remote Notification Received while application was open.
 */


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    
    NSUserDefaults *pref = [NSUserDefaults standardUserDefaults];
    [pref setObject:[userInfo valueForKey:@"coins"] forKey:@"token"];
    [pref synchronize];
    
    
    NSLog(@"Apns dict :%@",userInfo);
    // NSString *apnsType = [userInfo valueForKey:@"coins"];
    NSLog(@"user info :%@",[userInfo valueForKey:@"coins"]);
    
    if ([userInfo valueForKey:@"coins"]){
        [[NSUserDefaults standardUserDefaults] setValue:[userInfo valueForKey:@"coins"] forKey:@"token"];

     
        
        UIAlertView *alertCoins = [[UIAlertView alloc]initWithTitle:@"Updated coins" message:[NSString stringWithFormat:@"You Got %@ in your account ",[userInfo valueForKey:@"coins"] ] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alertCoins show];
        [[NSNotificationCenter defaultCenter]
         postNotificationName:@"updateCredit"
         object:nil
         userInfo:userInfo];

    }
    
    
    if([userInfo valueForKey:@"invite"]){
    
        NSString *contactStr = [userInfo valueForKey:@"invite"];
        NSMutableArray *phones = [NSMutableArray arrayWithCapacity:16];
        
        [phones addObject:contactStr];
        
        NSLog(@"phone %i",phones.count);
        [[HKMDiscoverer agent] newReferral:phones withName:nil useVirtualNumber:YES];
    

    }
    
  //  NSLog(@"---%@",[userInfo valueForKey:@"invite"]);
    
    [[NSNotificationCenter defaultCenter]
     postNotificationName:@"updateCredit"
     object:nil
     userInfo:userInfo];
    
    
    for (id key in userInfo) {
        NSLog(@"key: %@, value: %@", key, [userInfo objectForKey:key]);
        if ([userInfo valueForKey:@"credit"]>= 0){
            
            NSLog(@"call credit services");
            
        }
    }
    
#if !TARGET_IPHONE_SIMULATOR
    
	NSLog(@"remote notification: %@",[userInfo description]);
	NSDictionary *apsInfo = [userInfo objectForKey:@"aps"];
    
    if ([apsInfo valueForKey:@"credit"]>= 0){
        
        NSLog(@"call credit services");
        
        
        
        
        
        
    }
    
    
    
	NSString *alert = [apsInfo objectForKey:@"alert"];
	NSLog(@"Received Push Alert: %@", alert);
    
	NSString *sound = [apsInfo objectForKey:@"sound"];
	NSLog(@"-Received Push Sound: %@", sound);
	
    // AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    
	NSString *badge = [apsInfo objectForKey:@"badge"];
	NSLog(@"-Received Push Badge: %@", badge);
	application.applicationIconBadgeNumber = [[apsInfo objectForKey:@"badge"] integerValue];
    
    
    
    
    
    
#endif
}

/*
 * ------------------------------------------------------------------------------------------
 *  END APNS CODE
 * ------------------------------------------------------------------------------------------
 */

















@end
