//
//  FQViewController.h
//  Friend-Quiz
//
//  Created by Ashish Kumar on 13/02/13.
//  Copyright (c) 2013 FriendsQuiz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HKMDiscoverer.h"
#import <AddressBook/AddressBook.h>
#import <StoreKit/StoreKit.h>
#import <AddressBookUI/AddressBookUI.h>



@interface FQViewController : UIViewController<UIWebViewDelegate,SKPaymentTransactionObserver, SKProductsRequestDelegate,SKStoreProductViewControllerDelegate,NSURLConnectionDelegate,UIAlertViewDelegate,UITextFieldDelegate>
{

    ABAddressBookRef addressBook;

}
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@property (strong, nonatomic) IBOutlet UIWebView *htmlView;

@property (retain, nonatomic)NSString *myDeviceToken;
@property (retain, nonatomic)NSString *updatedCoin;
@property (retain, nonatomic) NSMutableString *myContactString;


@property (strong, nonatomic) SKProduct *product;
@property (strong, nonatomic) NSString *productID;

@property (retain, nonatomic)NSMutableArray *wantedname;
@property (retain, nonatomic)NSMutableArray *wantednumber;
@property (retain, nonatomic)NSMutableArray *wantedLastname;

@property (retain, nonatomic)NSMutableArray *finalContacts;


@property (strong, nonatomic)NSString *phoneNumber;
@property (strong, nonatomic)NSMutableArray *someArray;
@property (retain, nonatomic)NSString *purchasedCoins;
@property (retain, nonatomic)UITextField *myTextField;


@property (assign, readwrite)BOOL number;

@property (assign, readwrite)BOOL service;


@property(strong,nonatomic)UIView *myview;
@property(strong,nonatomic)UITextField *myfield;
@property(strong,nonatomic)UITextField *myfield2;
@property(strong,nonatomic)UITextField *num1,*num2,*num3;

@property(strong,nonatomic)UILabel *mylabel;
@property(strong,nonatomic)UIButton *mybutton,*mybutton1;

@property(strong,nonatomic) NSMutableString *myString;



-(void)purchaseItem :(NSString*)creditStr :(NSString*)productIdt;

- (void) completeTransaction: (SKPaymentTransaction *)transaction;
- (void) restoreTransaction: (SKPaymentTransaction *)transaction;
- (void) failedTransaction: (SKPaymentTransaction *)transaction;





@end
