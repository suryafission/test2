//
//  FQAppDelegate.h
//  Friend-Quiz
//
//  Created by Ashish Kumar on 13/02/13.
//  Copyright (c) 2013 FriendsQuiz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HKMDiscoverer.h"


@class FQViewController;


@interface FQAppDelegate : UIResponder <UIApplicationDelegate,NSURLConnectionDelegate>

@property (strong, nonatomic) UIWindow *window;





@property (retain, nonatomic)NSString *myDeviceToken;
@property(assign, readwrite)BOOL isOPEN;



@end
